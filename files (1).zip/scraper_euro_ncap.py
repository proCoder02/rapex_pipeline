"""
Euro NCAP scraper for vehicle safety ratings
"""

import logging
import json
import re
from typing import List, Dict, Any
from bs4 import BeautifulSoup

from utils import (
    setup_logging, create_session, safe_get,
    retry_on_exception, clean_text
)
from database import AutomotiveDatabase
from config import DATA_SOURCES, RAW_DATA_DIR


logger = setup_logging()


class EuroNCAPScraper:
    """Scraper for Euro NCAP vehicle safety ratings"""
    
    def __init__(self):
        self.session = create_session()
        self.base_url = DATA_SOURCES["euro_ncap"]["base_url"]
        self.results_url = DATA_SOURCES["euro_ncap"]["results_url"]
        self.domain = "euro_ncap"
    
    @retry_on_exception(max_attempts=3)
    def get_results_page(self, year: int = None) -> BeautifulSoup:
        """
        Fetch the Euro NCAP results page
        
        Args:
            year: Specific year to filter (optional)
        
        Returns:
            BeautifulSoup object of the page
        """
        url = self.results_url
        if year:
            url = f"{self.results_url}{year}/"
        
        response = safe_get(url, self.session, self.domain)
        return BeautifulSoup(response.content, 'html.parser')
    
    def extract_rating_value(self, text: str) -> float:
        """Extract numeric rating from text"""
        if not text:
            return None
        
        # Look for percentage or star rating
        match = re.search(r'(\d+(?:\.\d+)?)', text)
        if match:
            value = float(match.group(1))
            # If it's a percentage, convert to 0-5 scale
            if value > 5:
                return round(value / 20, 2)  # Convert % to stars
            return value
        return None
    
    def parse_vehicle_card(self, card_element) -> Dict[str, Any]:
        """
        Parse a vehicle card element from the results page
        
        Args:
            card_element: BeautifulSoup element representing a vehicle card
        
        Returns:
            Dictionary of vehicle safety rating data
        """
        try:
            # Extract basic information
            make = clean_text(card_element.find('span', class_='make').text if card_element.find('span', class_='make') else '')
            model = clean_text(card_element.find('span', class_='model').text if card_element.find('span', class_='model') else '')
            
            # Extract year
            year_elem = card_element.find('span', class_='year')
            year = int(year_elem.text) if year_elem and year_elem.text.strip().isdigit() else None
            
            # Extract overall rating (usually shown as stars)
            overall_rating = None
            rating_elem = card_element.find('div', class_='rating')
            if rating_elem:
                stars_elem = rating_elem.find('span', class_='stars')
                if stars_elem and 'data-rating' in stars_elem.attrs:
                    overall_rating = float(stars_elem['data-rating'])
            
            # Extract category scores
            scores = {}
            score_categories = card_element.find_all('div', class_='score-category')
            for category in score_categories:
                category_name = category.get('data-category', '').lower().replace(' ', '_')
                score_value = category.get('data-score')
                if score_value:
                    scores[category_name] = float(score_value)
            
            # Build the rating data
            rating_data = {
                'make': make,
                'model': model,
                'year': year,
                'variant': clean_text(card_element.find('span', class_='variant').text if card_element.find('span', class_='variant') else ''),
                'overall_rating': overall_rating,
                'adult_occupant': scores.get('adult_occupant'),
                'child_occupant': scores.get('child_occupant'),
                'vulnerable_road_users': scores.get('vulnerable_road_users'),
                'safety_assist': scores.get('safety_assist'),
                'test_date': clean_text(card_element.find('span', class_='test-date').text if card_element.find('span', class_='test-date') else ''),
                'protocol_version': clean_text(card_element.find('span', class_='protocol').text if card_element.find('span', class_='protocol') else ''),
                'source_url': self.base_url + card_element.find('a')['href'] if card_element.find('a') else self.results_url
            }
            
            return rating_data
            
        except Exception as e:
            logging.error(f"Error parsing vehicle card: {e}")
            return None
    
    @retry_on_exception(max_attempts=3)
    def get_vehicle_details(self, vehicle_url: str) -> Dict[str, Any]:
        """
        Fetch detailed information for a specific vehicle
        
        Args:
            vehicle_url: URL to the vehicle's detail page
        
        Returns:
            Dictionary of detailed rating information
        """
        response = safe_get(vehicle_url, self.session, self.domain)
        soup = BeautifulSoup(response.content, 'html.parser')
        
        details = {}
        
        # Extract detailed scores
        score_sections = soup.find_all('div', class_='score-section')
        for section in score_sections:
            category = clean_text(section.find('h3').text if section.find('h3') else '')
            score_elem = section.find('span', class_='score-value')
            if score_elem:
                details[category.lower().replace(' ', '_')] = self.extract_rating_value(score_elem.text)
        
        return details
    
    def scrape_year(self, year: int) -> List[Dict[str, Any]]:
        """
        Scrape all safety ratings for a specific year
        
        Args:
            year: Year to scrape
        
        Returns:
            List of rating dictionaries
        """
        logging.info(f"Scraping Euro NCAP ratings for {year}")
        
        soup = self.get_results_page(year)
        vehicle_cards = soup.find_all('div', class_='vehicle-card')
        
        ratings = []
        for card in vehicle_cards:
            rating_data = self.parse_vehicle_card(card)
            if rating_data and rating_data.get('make'):
                ratings.append(rating_data)
        
        logging.info(f"Found {len(ratings)} vehicles for {year}")
        return ratings
    
    def scrape_all_years(self, start_year: int = 2015, end_year: int = None) -> List[Dict[str, Any]]:
        """
        Scrape safety ratings for a range of years
        
        Args:
            start_year: Starting year
            end_year: Ending year (defaults to current year)
        
        Returns:
            List of all rating dictionaries
        """
        if end_year is None:
            from datetime import datetime
            end_year = datetime.now().year
        
        all_ratings = []
        
        for year in range(start_year, end_year + 1):
            try:
                year_ratings = self.scrape_year(year)
                all_ratings.extend(year_ratings)
            except Exception as e:
                logging.error(f"Error scraping year {year}: {e}")
                continue
        
        logging.info(f"Scraped {len(all_ratings)} total ratings from Euro NCAP")
        
        # Save raw data
        raw_file = RAW_DATA_DIR / f"euro_ncap_ratings_{start_year}_{end_year}.json"
        with open(raw_file, 'w', encoding='utf-8') as f:
            json.dump(all_ratings, f, indent=2, ensure_ascii=False)
        logging.info(f"Saved raw data to {raw_file}")
        
        return all_ratings
    
    def scrape_and_save(self, start_year: int = 2015, end_year: int = None) -> int:
        """
        Scrape ratings and save to database
        
        Args:
            start_year: Starting year
            end_year: Ending year (defaults to current year)
        
        Returns:
            Number of ratings saved
        """
        ratings = self.scrape_all_years(start_year, end_year)
        
        # Save to database
        saved_count = 0
        with AutomotiveDatabase() as db:
            for rating in ratings:
                if db.insert_safety_rating(rating):
                    saved_count += 1
            
            db.log_scrape("euro_ncap", saved_count, "success")
        
        logging.info(f"Saved {saved_count} ratings to database")
        return saved_count


if __name__ == "__main__":
    # Example usage
    scraper = EuroNCAPScraper()
    
    # Scrape data from 2020 to present
    from datetime import datetime
    current_year = datetime.now().year
    count = scraper.scrape_and_save(start_year=2020, end_year=current_year)
    print(f"Scraped and saved {count} safety ratings")

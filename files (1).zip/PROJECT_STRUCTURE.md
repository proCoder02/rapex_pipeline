# Automotive Data Pipeline - Project Structure

```
automotive-data-pipeline/
│
├── 📄 Core Python Modules
│   ├── config.py                    # Configuration settings and constants
│   ├── utils.py                     # Utility functions (rate limiting, retry logic)
│   ├── database.py                  # SQLite database management
│   ├── pipeline.py                  # Main orchestrator (entry point)
│   │
│   └── 🔍 Scrapers
│       ├── scraper_safety_gate.py   # EU Safety Gate (RAPEX) scraper
│       └── scraper_euro_ncap.py     # Euro NCAP safety ratings scraper
│
├── 📚 Documentation
│   ├── README.md                    # Comprehensive documentation
│   ├── QUICKSTART.md                # Quick start guide
│   ├── LEGAL_COMPLIANCE.md          # Legal and ethical guidelines
│   └── PROJECT_STRUCTURE.md         # This file
│
├── 🎯 Usage & Examples
│   ├── examples.py                  # 7 example use cases
│   └── requirements.txt             # Python dependencies
│
├── ⚙️ Configuration
│   └── .gitignore                   # Git ignore file
│
└── 📁 Data Directories (Created on first run)
    ├── data/
    │   ├── automotive_data.db       # SQLite database
    │   ├── raw/                     # Raw JSON data from scrapers
    │   │   ├── safety_gate_recalls_*.json
    │   │   └── euro_ncap_ratings_*.json
    │   └── processed/               # Exported CSV/Excel files
    │       ├── vehicle_recalls_*.csv
    │       ├── safety_ratings_*.csv
    │       └── automotive_data_*.xlsx
    │
    └── logs/
        └── scraping.log             # Application logs

```

## 📋 File Descriptions

### Core Modules

#### `config.py`
- Central configuration for all settings
- Rate limiting parameters
- Database paths
- Data source URLs
- Export formats

#### `utils.py`
- Rate limiter class (RateLimiter)
- Session creation with retry logic
- Safe HTTP request functions (safe_get, safe_post)
- Retry decorators
- Text cleaning and date parsing utilities

#### `database.py`
- AutomotiveDatabase class
- SQLite table creation and management
- Data insertion methods (recalls, ratings, commercial status)
- Data export functions (CSV, Excel)
- Query methods with pandas DataFrame output

#### `pipeline.py`
- Main orchestrator class (AutomotiveDataPipeline)
- Command-line interface
- Coordinates all scrapers
- Generates summary reports
- Statistics generation

#### `scraper_safety_gate.py`
- EUSafetyGateScraper class
- Scrapes vehicle recalls from EU Safety Gate
- API-based scraping with pagination
- Data extraction and normalization

#### `scraper_euro_ncap.py`
- EuroNCAPScraper class
- Scrapes safety ratings from Euro NCAP
- HTML parsing with BeautifulSoup
- Multi-year scraping capability

### Documentation Files

#### `README.md`
- Complete project documentation
- Installation instructions
- Usage examples
- Configuration guide
- Troubleshooting tips
- Legal considerations

#### `QUICKSTART.md`
- 5-minute getting started guide
- Common commands
- Quick examples
- Essential tips

#### `LEGAL_COMPLIANCE.md`
- Legal framework overview
- Ethical guidelines
- Risk assessment
- Source-specific guidelines
- Best practices

### Example Scripts

#### `examples.py`
- 7 practical examples:
  1. Quick start (30 days)
  2. Specific year scraping
  3. Data analysis
  4. Filtered exports
  5. Incremental updates
  6. Combined analysis
  7. Test mode
- Interactive menu
- Reusable code patterns

## 🔄 Data Flow

```
1. User Input
   ↓
2. Pipeline Orchestrator (pipeline.py)
   ↓
3. Scraper Selection
   ├── Safety Gate Scraper → EU Safety Gate API
   └── Euro NCAP Scraper → Euro NCAP Website
   ↓
4. Data Collection
   ├── Rate Limiting (utils.py)
   ├── Retry Logic (utils.py)
   └── Error Handling
   ↓
5. Data Storage
   ├── Raw JSON (data/raw/)
   └── SQLite Database (database.py)
   ↓
6. Data Export
   ├── CSV Files (data/processed/)
   └── Excel Workbooks (data/processed/)
   ↓
7. Analysis & Reporting
   └── Statistics & Summaries
```

## 🎯 Key Features by Module

### Rate Limiting (`utils.py`)
```python
- Tracks requests per domain
- Enforces configurable limits
- Automatic waiting when limit reached
- Per-source customization
```

### Error Handling (`utils.py`)
```python
- Exponential backoff retry
- Maximum retry limits
- Comprehensive logging
- Graceful failure modes
```

### Database Management (`database.py`)
```python
- Automatic table creation
- Duplicate prevention (UNIQUE constraints)
- Transaction support
- Multiple export formats
- Query helpers with pandas
```

### Data Validation
```python
- Text cleaning and normalization
- Date parsing with multiple formats
- Data type validation
- NULL handling
```

## 🔌 Extension Points

### Adding New Scrapers
1. Create new file: `scraper_[source].py`
2. Implement scraper class
3. Add to `config.py` DATA_SOURCES
4. Integrate in `pipeline.py`
5. Add database table in `database.py`

### Adding New Data Types
1. Define new table in `database.py`
2. Create insert/query methods
3. Add to export functions
4. Update documentation

### Custom Analysis
1. Use `database.py` query methods
2. Leverage pandas DataFrames
3. Add to `examples.py`
4. Export results

## 📊 Database Schema

### vehicle_recalls
```sql
- id (PRIMARY KEY)
- reference_number (UNIQUE)
- notification_date
- country_of_origin
- product_category
- product_name
- brand, type, model
- risk_type, risk_description
- measures_taken
- notifying_country
- source_url
- scraped_at
```

### safety_ratings
```sql
- id (PRIMARY KEY)
- make, model, year, variant (UNIQUE together)
- overall_rating
- adult_occupant
- child_occupant
- vulnerable_road_users
- safety_assist
- test_date
- protocol_version
- source_url
- scraped_at
```

### commercial_use_status
```sql
- id (PRIMARY KEY)
- make, model, year (UNIQUE together)
- is_commercial
- vehicle_type
- weight_class
- seating_capacity
- source, notes
- scraped_at
```

### scraping_metadata
```sql
- id (PRIMARY KEY)
- source
- scrape_date
- records_scraped
- status
- error_message
```

## 🚀 Usage Patterns

### Command Line
```bash
# Full pipeline
python pipeline.py --full

# Individual sources
python pipeline.py --safety-gate --days 90
python pipeline.py --euro-ncap --start-year 2020

# Statistics only
python pipeline.py --stats
```

### Programmatic
```python
from pipeline import AutomotiveDataPipeline
from database import AutomotiveDatabase

# Use pipeline
pipeline = AutomotiveDataPipeline()
pipeline.run_full_pipeline()
pipeline.close()

# Direct database access
with AutomotiveDatabase() as db:
    recalls = db.get_recalls()
    db.export_to_excel()
```

### Examples
```bash
# Interactive examples
python examples.py

# Specific example
python -c "from examples import example_3_data_analysis; example_3_data_analysis()"
```

## 📝 Configuration Options

### Rate Limits (config.py)
```python
RATE_LIMITS = {
    "eu_safety_gate": 10,  # requests/minute
    "euro_ncap": 8,
    "default": 5
}
```

### Retry Settings (config.py)
```python
MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds
BACKOFF_FACTOR = 2
```

### Logging (config.py)
```python
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
```

## 🔒 Security Considerations

1. **Data Protection**: Database not exposed publicly
2. **API Keys**: No hardcoded credentials
3. **Input Validation**: All user inputs sanitized
4. **Error Messages**: No sensitive data in logs
5. **Dependencies**: Regular updates recommended

## 🤝 Contributing

To extend this pipeline:
1. Follow existing code structure
2. Add comprehensive logging
3. Include error handling
4. Update documentation
5. Add examples
6. Test thoroughly

---

**Version**: 1.0
**Last Updated**: December 2025

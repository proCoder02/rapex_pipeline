# Automotive Data Scraping Pipeline

A production-ready Python data pipeline for collecting publicly available automotive data from multiple sources, including vehicle recalls, safety ratings, and commercial use status.

## Features

- **Multi-Source Data Collection**:
  - EU Safety Gate (RAPEX): Vehicle recalls and safety alerts
  - Euro NCAP: Vehicle safety ratings and crash test results
  - Commercial Use Status: Vehicle classification data

- **Robust Scraping Infrastructure**:
  - Automatic rate limiting to respect server resources
  - Retry logic with exponential backoff
  - Error handling and logging
  - Progress tracking and metadata

- **Data Management**:
  - SQLite database for structured storage
  - CSV and Excel export capabilities
  - Raw data preservation in JSON format
  - Duplicate prevention

## Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Setup

1. **Clone or download the project**

2. **Install dependencies**:
```bash
pip install -r requirements.txt
```

3. **Verify installation**:
```bash
python pipeline.py --help
```

## Project Structure

```
automotive-data-pipeline/
├── config.py                    # Configuration settings
├── utils.py                     # Utility functions (rate limiting, retry logic)
├── database.py                  # Database management
├── scraper_safety_gate.py       # EU Safety Gate scraper
├── scraper_euro_ncap.py         # Euro NCAP scraper
├── pipeline.py                  # Main orchestrator
├── requirements.txt             # Python dependencies
├── data/
│   ├── raw/                     # Raw JSON data
│   ├── processed/               # CSV and Excel exports
│   └── automotive_data.db       # SQLite database
└── logs/
    └── scraping.log             # Application logs
```

## Usage

### Quick Start

Run the complete pipeline (default settings):
```bash
python pipeline.py --full
```

This will:
- Scrape vehicle recalls from the last 180 days
- Scrape safety ratings from 2015 to present
- Save all data to SQLite database
- Export CSV and Excel files
- Display statistics

### Command-Line Options

#### Run Full Pipeline
```bash
# Default: 180 days of recalls, Euro NCAP from 2015
python pipeline.py --full

# Custom date ranges
python pipeline.py --full --days 90 --start-year 2020
```

#### Run Individual Scrapers

**EU Safety Gate only**:
```bash
# Last 180 days
python pipeline.py --safety-gate

# Last 90 days
python pipeline.py --safety-gate --days 90

# Limit to 10 pages
python pipeline.py --safety-gate --max-pages 10
```

**Euro NCAP only**:
```bash
# From 2015 to present
python pipeline.py --euro-ncap

# From 2020 to present
python pipeline.py --euro-ncap --start-year 2020
```

#### View Statistics
```bash
# Display stats without scraping
python pipeline.py --stats
```

### Programmatic Usage

```python
from pipeline import AutomotiveDataPipeline
from database import AutomotiveDatabase

# Create pipeline instance
pipeline = AutomotiveDataPipeline()

# Run individual scrapers
recalls_count = pipeline.run_safety_gate_scrape(days_back=90)
ratings_count = pipeline.run_euro_ncap_scrape(start_year=2020)

# Get statistics
pipeline.get_statistics()

# Access database directly
with AutomotiveDatabase() as db:
    recalls_df = db.get_recalls(limit=100)
    ratings_df = db.get_safety_ratings()
    
    # Export data
    db.export_to_csv('vehicle_recalls')
    db.export_to_excel()

pipeline.close()
```

## Data Sources

### 1. EU Safety Gate (RAPEX)
- **URL**: https://ec.europa.eu/safety-gate-alerts
- **Data**: Vehicle recalls and safety alerts
- **Fields**:
  - Reference number
  - Notification date
  - Country of origin
  - Product details (make, model, type)
  - Risk type and description
  - Measures taken
  - Notifying country

### 2. Euro NCAP
- **URL**: https://www.euroncap.com
- **Data**: Vehicle safety ratings
- **Fields**:
  - Make, model, year, variant
  - Overall rating (0-5 stars)
  - Adult occupant protection
  - Child occupant protection
  - Vulnerable road users
  - Safety assist systems
  - Test date and protocol version

## Configuration

Edit `config.py` to customize:

```python
# Rate limits (requests per minute)
RATE_LIMITS = {
    "eu_safety_gate": 10,
    "euro_ncap": 8,
    "default": 5
}

# Retry settings
MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds
BACKOFF_FACTOR = 2

# Export formats
EXPORT_FORMATS = ["csv", "json", "excel"]
```

## Best Practices & Legal Considerations

### Ethical Web Scraping

1. **Respect robots.txt**: Check the site's robots.txt file
2. **Rate limiting**: Built-in delays prevent server overload
3. **User-Agent**: Identifies our scraper to servers
4. **Error handling**: Graceful failure without hammering servers
5. **Data caching**: Raw data saved to avoid re-scraping

### Legal Compliance

⚠️ **Important Legal Notices**:

1. **Public Data Only**: This pipeline scrapes only publicly available data
2. **Terms of Service**: Review each website's Terms of Service before use
3. **Data Usage**: Comply with any usage restrictions
4. **Attribution**: Credit data sources when publishing results
5. **Research Purposes**: This tool is designed for research and analysis

### Anti-Bot Protection Handling

The pipeline includes:
- **Randomized delays**: Mimics human browsing patterns
- **Session management**: Maintains cookies and headers
- **Retry logic**: Handles temporary failures
- **User-Agent rotation**: Can be customized for different profiles

If you encounter CAPTCHAs or blocking:
1. Reduce scraping frequency (increase delays)
2. Use residential proxies (requires additional setup)
3. Consider official APIs if available
4. Contact website administrators for data access

## Troubleshooting

### Common Issues

**1. Rate Limiting / 429 Errors**
```python
# Increase delays in config.py
RATE_LIMITS = {
    "eu_safety_gate": 5,  # Reduced from 10
    "euro_ncap": 4,       # Reduced from 8
}
```

**2. Connection Timeouts**
```python
# In utils.py, increase timeout
response = session.get(url, timeout=60)  # Increased from 30
```

**3. Parsing Errors**
- Websites may have updated their HTML structure
- Check logs/scraping.log for details
- Update the scraper's parsing logic

**4. Database Locked**
- Close other connections: `pipeline.close()`
- Check for zombie processes

### Debug Mode

Enable detailed logging:
```python
# In config.py
LOG_LEVEL = "DEBUG"  # Changed from "INFO"
```

## Data Export

### SQLite Database
- Location: `data/automotive_data.db`
- Tables: `vehicle_recalls`, `safety_ratings`, `commercial_use_status`, `scraping_metadata`

### CSV Files
- Location: `data/processed/`
- One file per table
- Timestamped filenames

### Excel Workbook
- Location: `data/processed/automotive_data_YYYYMMDD.xlsx`
- Separate sheets for each data type
- Formatted for easy analysis

## Extending the Pipeline

### Adding New Data Sources

1. Create new scraper file:
```python
# scraper_new_source.py
from utils import setup_logging, create_session, safe_get
from database import AutomotiveDatabase

class NewSourceScraper:
    def __init__(self):
        self.session = create_session()
        self.domain = "new_source"
    
    def scrape_and_save(self):
        # Your scraping logic here
        pass
```

2. Add to config.py:
```python
DATA_SOURCES["new_source"] = {
    "base_url": "https://example.com",
    "description": "Description of data source"
}
```

3. Integrate in pipeline.py:
```python
from scraper_new_source import NewSourceScraper

class AutomotiveDataPipeline:
    def __init__(self):
        # ... existing code ...
        self.new_scraper = NewSourceScraper()
```

## Performance Tips

1. **Use max_pages for testing**:
```bash
python pipeline.py --safety-gate --max-pages 5
```

2. **Scrape recent data first**:
```bash
python pipeline.py --safety-gate --days 30
```

3. **Run scrapers separately during development**:
```bash
python scraper_safety_gate.py
python scraper_euro_ncap.py
```

4. **Schedule periodic updates**:
```bash
# Using cron (Linux/Mac)
0 2 * * * /path/to/python /path/to/pipeline.py --full

# Using Task Scheduler (Windows)
# Create task to run: python pipeline.py --full
```

## Monitoring

Check logs for pipeline health:
```bash
tail -f logs/scraping.log
```

Query scraping metadata:
```sql
SELECT * FROM scraping_metadata ORDER BY scrape_date DESC LIMIT 10;
```

## License

This project is for educational and research purposes. Users are responsible for ensuring compliance with all applicable laws and website terms of service.

## Support

For issues or questions:
1. Check logs: `logs/scraping.log`
2. Review website changes (may require scraper updates)
3. Verify network connectivity
4. Check rate limiting settings

## Acknowledgments

Data sources:
- European Commission - EU Safety Gate
- Euro NCAP - European New Car Assessment Programme

---

**Disclaimer**: This tool is provided as-is for research purposes. Users are responsible for complying with all applicable laws, regulations, and website terms of service. The authors are not responsible for misuse of this software.

"""
Database module for storing automotive data
"""

import sqlite3
import logging
import pandas as pd
from typing import List, Dict, Any
from datetime import datetime
from pathlib import Path

from config import DB_PATH, PROCESSED_DATA_DIR


class AutomotiveDatabase:
    """Database handler for automotive data"""
    
    def __init__(self, db_path: Path = DB_PATH):
        """Initialize database connection"""
        self.db_path = db_path
        self.conn = None
        self.cursor = None
        self._connect()
        self._create_tables()
    
    def _connect(self):
        """Establish database connection"""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.cursor = self.conn.cursor()
            logging.info(f"Connected to database: {self.db_path}")
        except sqlite3.Error as e:
            logging.error(f"Database connection error: {e}")
            raise
    
    def _create_tables(self):
        """Create necessary tables if they don't exist"""
        
        # Vehicle recalls table (EU Safety Gate / RAPEX)
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS vehicle_recalls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                reference_number TEXT UNIQUE,
                notification_date TEXT,
                country_of_origin TEXT,
                product_category TEXT,
                product_name TEXT,
                brand TEXT,
                type TEXT,
                model TEXT,
                risk_type TEXT,
                risk_description TEXT,
                measures_taken TEXT,
                notifying_country TEXT,
                source_url TEXT,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Euro NCAP safety ratings table
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS safety_ratings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                make TEXT,
                model TEXT,
                year INTEGER,
                variant TEXT,
                overall_rating REAL,
                adult_occupant REAL,
                child_occupant REAL,
                vulnerable_road_users REAL,
                safety_assist REAL,
                test_date TEXT,
                protocol_version TEXT,
                source_url TEXT,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(make, model, year, variant)
            )
        """)
        
        # Commercial use status table (can be populated from various sources)
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS commercial_use_status (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                make TEXT,
                model TEXT,
                year INTEGER,
                is_commercial BOOLEAN,
                vehicle_type TEXT,
                weight_class TEXT,
                seating_capacity INTEGER,
                source TEXT,
                notes TEXT,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(make, model, year)
            )
        """)
        
        # Scraping metadata table
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS scraping_metadata (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT,
                scrape_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                records_scraped INTEGER,
                status TEXT,
                error_message TEXT
            )
        """)
        
        self.conn.commit()
        logging.info("Database tables created/verified")
    
    def insert_recall(self, recall_data: Dict[str, Any]) -> bool:
        """Insert vehicle recall data"""
        try:
            self.cursor.execute("""
                INSERT OR REPLACE INTO vehicle_recalls 
                (reference_number, notification_date, country_of_origin, product_category,
                 product_name, brand, type, model, risk_type, risk_description,
                 measures_taken, notifying_country, source_url)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                recall_data.get('reference_number'),
                recall_data.get('notification_date'),
                recall_data.get('country_of_origin'),
                recall_data.get('product_category'),
                recall_data.get('product_name'),
                recall_data.get('brand'),
                recall_data.get('type'),
                recall_data.get('model'),
                recall_data.get('risk_type'),
                recall_data.get('risk_description'),
                recall_data.get('measures_taken'),
                recall_data.get('notifying_country'),
                recall_data.get('source_url')
            ))
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            logging.error(f"Error inserting recall data: {e}")
            return False
    
    def insert_safety_rating(self, rating_data: Dict[str, Any]) -> bool:
        """Insert Euro NCAP safety rating data"""
        try:
            self.cursor.execute("""
                INSERT OR REPLACE INTO safety_ratings 
                (make, model, year, variant, overall_rating, adult_occupant,
                 child_occupant, vulnerable_road_users, safety_assist,
                 test_date, protocol_version, source_url)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                rating_data.get('make'),
                rating_data.get('model'),
                rating_data.get('year'),
                rating_data.get('variant'),
                rating_data.get('overall_rating'),
                rating_data.get('adult_occupant'),
                rating_data.get('child_occupant'),
                rating_data.get('vulnerable_road_users'),
                rating_data.get('safety_assist'),
                rating_data.get('test_date'),
                rating_data.get('protocol_version'),
                rating_data.get('source_url')
            ))
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            logging.error(f"Error inserting safety rating data: {e}")
            return False
    
    def insert_commercial_status(self, commercial_data: Dict[str, Any]) -> bool:
        """Insert commercial use status data"""
        try:
            self.cursor.execute("""
                INSERT OR REPLACE INTO commercial_use_status 
                (make, model, year, is_commercial, vehicle_type, weight_class,
                 seating_capacity, source, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                commercial_data.get('make'),
                commercial_data.get('model'),
                commercial_data.get('year'),
                commercial_data.get('is_commercial'),
                commercial_data.get('vehicle_type'),
                commercial_data.get('weight_class'),
                commercial_data.get('seating_capacity'),
                commercial_data.get('source'),
                commercial_data.get('notes')
            ))
            self.conn.commit()
            return True
        except sqlite3.Error as e:
            logging.error(f"Error inserting commercial status data: {e}")
            return False
    
    def log_scrape(self, source: str, records_scraped: int, 
                   status: str = "success", error_message: str = None):
        """Log scraping metadata"""
        try:
            self.cursor.execute("""
                INSERT INTO scraping_metadata 
                (source, records_scraped, status, error_message)
                VALUES (?, ?, ?, ?)
            """, (source, records_scraped, status, error_message))
            self.conn.commit()
        except sqlite3.Error as e:
            logging.error(f"Error logging scrape metadata: {e}")
    
    def get_recalls(self, limit: int = None) -> pd.DataFrame:
        """Retrieve vehicle recalls as DataFrame"""
        query = "SELECT * FROM vehicle_recalls ORDER BY notification_date DESC"
        if limit:
            query += f" LIMIT {limit}"
        return pd.read_sql_query(query, self.conn)
    
    def get_safety_ratings(self, limit: int = None) -> pd.DataFrame:
        """Retrieve safety ratings as DataFrame"""
        query = "SELECT * FROM safety_ratings ORDER BY test_date DESC"
        if limit:
            query += f" LIMIT {limit}"
        return pd.read_sql_query(query, self.conn)
    
    def get_commercial_status(self, limit: int = None) -> pd.DataFrame:
        """Retrieve commercial use status as DataFrame"""
        query = "SELECT * FROM commercial_use_status ORDER BY year DESC"
        if limit:
            query += f" LIMIT {limit}"
        return pd.read_sql_query(query, self.conn)
    
    def export_to_csv(self, table_name: str, output_file: Path = None):
        """Export table data to CSV"""
        if output_file is None:
            output_file = PROCESSED_DATA_DIR / f"{table_name}_{datetime.now().strftime('%Y%m%d')}.csv"
        
        df = pd.read_sql_query(f"SELECT * FROM {table_name}", self.conn)
        df.to_csv(output_file, index=False)
        logging.info(f"Exported {table_name} to {output_file}")
        return output_file
    
    def export_to_excel(self, output_file: Path = None):
        """Export all tables to Excel with separate sheets"""
        if output_file is None:
            output_file = PROCESSED_DATA_DIR / f"automotive_data_{datetime.now().strftime('%Y%m%d')}.xlsx"
        
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            for table in ['vehicle_recalls', 'safety_ratings', 'commercial_use_status']:
                df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
                df.to_excel(writer, sheet_name=table, index=False)
        
        logging.info(f"Exported all data to {output_file}")
        return output_file
    
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            logging.info("Database connection closed")
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()

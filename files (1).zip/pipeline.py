"""
Main data pipeline orchestrator for automotive data scraping
"""

import logging
import argparse
from datetime import datetime, timedelta
from pathlib import Path

from utils import setup_logging
from database import AutomotiveDatabase
from scraper_safety_gate import EUSafetyGateScraper
from scraper_euro_ncap import EuroNCAPScraper
from config import PROCESSED_DATA_DIR


logger = setup_logging()


class AutomotiveDataPipeline:
    """Main pipeline for orchestrating automotive data collection"""
    
    def __init__(self):
        self.db = AutomotiveDatabase()
        self.safety_gate_scraper = EUSafetyGateScraper()
        self.euro_ncap_scraper = EuroNCAPScraper()
    
    def run_safety_gate_scrape(self, days_back: int = 180, max_pages: int = None):
        """
        Run EU Safety Gate scraping
        
        Args:
            days_back: Number of days to look back for recalls
            max_pages: Maximum pages to scrape (None for all)
        """
        logger.info("=" * 80)
        logger.info("Starting EU Safety Gate (RAPEX) scraping")
        logger.info("=" * 80)
        
        end_date = datetime.now().strftime("%Y-%m-%d")
        start_date = (datetime.now() - timedelta(days=days_back)).strftime("%Y-%m-%d")
        
        try:
            count = self.safety_gate_scraper.scrape_and_save(
                start_date=start_date,
                end_date=end_date,
                max_pages=max_pages
            )
            logger.info(f"✓ Successfully scraped {count} vehicle recalls")
            return count
        except Exception as e:
            logger.error(f"✗ Error in Safety Gate scraping: {e}")
            self.db.log_scrape("eu_safety_gate", 0, "failed", str(e))
            return 0
    
    def run_euro_ncap_scrape(self, start_year: int = 2015, end_year: int = None):
        """
        Run Euro NCAP scraping
        
        Args:
            start_year: Starting year for scraping
            end_year: Ending year (defaults to current year)
        """
        logger.info("=" * 80)
        logger.info("Starting Euro NCAP safety ratings scraping")
        logger.info("=" * 80)
        
        if end_year is None:
            end_year = datetime.now().year
        
        try:
            count = self.euro_ncap_scraper.scrape_and_save(
                start_year=start_year,
                end_year=end_year
            )
            logger.info(f"✓ Successfully scraped {count} safety ratings")
            return count
        except Exception as e:
            logger.error(f"✗ Error in Euro NCAP scraping: {e}")
            self.db.log_scrape("euro_ncap", 0, "failed", str(e))
            return 0
    
    def run_full_pipeline(self, safety_gate_days: int = 180, 
                         euro_ncap_start_year: int = 2015):
        """
        Run the complete data pipeline
        
        Args:
            safety_gate_days: Days to look back for recalls
            euro_ncap_start_year: Starting year for Euro NCAP scraping
        """
        logger.info("=" * 80)
        logger.info("STARTING AUTOMOTIVE DATA PIPELINE")
        logger.info("=" * 80)
        
        start_time = datetime.now()
        
        # Run scrapers
        recalls_count = self.run_safety_gate_scrape(days_back=safety_gate_days)
        ratings_count = self.run_euro_ncap_scrape(start_year=euro_ncap_start_year)
        
        # Generate summary report
        self.generate_summary_report()
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        logger.info("=" * 80)
        logger.info("PIPELINE COMPLETE")
        logger.info(f"Duration: {duration:.2f} seconds")
        logger.info(f"Vehicle Recalls: {recalls_count}")
        logger.info(f"Safety Ratings: {ratings_count}")
        logger.info("=" * 80)
    
    def generate_summary_report(self):
        """Generate summary statistics and export data"""
        logger.info("Generating summary report...")
        
        # Get data counts
        recalls_df = self.db.get_recalls()
        ratings_df = self.db.get_safety_ratings()
        
        logger.info(f"Total Recalls in Database: {len(recalls_df)}")
        logger.info(f"Total Safety Ratings in Database: {len(ratings_df)}")
        
        # Export to CSV
        if len(recalls_df) > 0:
            recalls_file = self.db.export_to_csv('vehicle_recalls')
            logger.info(f"Exported recalls to: {recalls_file}")
        
        if len(ratings_df) > 0:
            ratings_file = self.db.export_to_csv('safety_ratings')
            logger.info(f"Exported ratings to: {ratings_file}")
        
        # Export to Excel (all data)
        try:
            excel_file = self.db.export_to_excel()
            logger.info(f"Exported combined data to: {excel_file}")
        except Exception as e:
            logger.error(f"Error exporting to Excel: {e}")
    
    def get_statistics(self):
        """Get and display pipeline statistics"""
        logger.info("=" * 80)
        logger.info("PIPELINE STATISTICS")
        logger.info("=" * 80)
        
        # Recalls statistics
        recalls_df = self.db.get_recalls()
        if len(recalls_df) > 0:
            logger.info(f"\nVehicle Recalls:")
            logger.info(f"  Total: {len(recalls_df)}")
            logger.info(f"  By Country:")
            country_counts = recalls_df['notifying_country'].value_counts().head(10)
            for country, count in country_counts.items():
                logger.info(f"    {country}: {count}")
            
            logger.info(f"  By Risk Type:")
            risk_counts = recalls_df['risk_type'].value_counts().head(5)
            for risk, count in risk_counts.items():
                logger.info(f"    {risk}: {count}")
        
        # Safety ratings statistics
        ratings_df = self.db.get_safety_ratings()
        if len(ratings_df) > 0:
            logger.info(f"\nSafety Ratings:")
            logger.info(f"  Total: {len(ratings_df)}")
            logger.info(f"  Average Overall Rating: {ratings_df['overall_rating'].mean():.2f}")
            logger.info(f"  By Make (Top 10):")
            make_counts = ratings_df['make'].value_counts().head(10)
            for make, count in make_counts.items():
                logger.info(f"    {make}: {count}")
        
        logger.info("=" * 80)
    
    def close(self):
        """Close database connection"""
        self.db.close()


def main():
    """Main entry point with command-line arguments"""
    parser = argparse.ArgumentParser(
        description="Automotive Data Scraping Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run full pipeline (default: last 180 days of recalls, Euro NCAP from 2015)
  python pipeline.py --full
  
  # Run only Safety Gate scraper for last 90 days
  python pipeline.py --safety-gate --days 90
  
  # Run only Euro NCAP scraper from 2020 to present
  python pipeline.py --euro-ncap --start-year 2020
  
  # Get statistics without scraping
  python pipeline.py --stats
        """
    )
    
    parser.add_argument('--full', action='store_true',
                       help='Run full pipeline (both scrapers)')
    parser.add_argument('--safety-gate', action='store_true',
                       help='Run Safety Gate scraper only')
    parser.add_argument('--euro-ncap', action='store_true',
                       help='Run Euro NCAP scraper only')
    parser.add_argument('--stats', action='store_true',
                       help='Display statistics only (no scraping)')
    parser.add_argument('--days', type=int, default=180,
                       help='Days to look back for Safety Gate recalls (default: 180)')
    parser.add_argument('--start-year', type=int, default=2015,
                       help='Starting year for Euro NCAP scraping (default: 2015)')
    parser.add_argument('--max-pages', type=int, default=None,
                       help='Maximum pages to scrape from Safety Gate (default: all)')
    
    args = parser.parse_args()
    
    # Create pipeline
    pipeline = AutomotiveDataPipeline()
    
    try:
        if args.stats:
            pipeline.get_statistics()
        elif args.full:
            pipeline.run_full_pipeline(
                safety_gate_days=args.days,
                euro_ncap_start_year=args.start_year
            )
            pipeline.get_statistics()
        elif args.safety_gate:
            pipeline.run_safety_gate_scrape(
                days_back=args.days,
                max_pages=args.max_pages
            )
            pipeline.get_statistics()
        elif args.euro_ncap:
            pipeline.run_euro_ncap_scrape(
                start_year=args.start_year
            )
            pipeline.get_statistics()
        else:
            # Default: run full pipeline
            pipeline.run_full_pipeline(
                safety_gate_days=args.days,
                euro_ncap_start_year=args.start_year
            )
            pipeline.get_statistics()
    
    finally:
        pipeline.close()


if __name__ == "__main__":
    main()

"""
EU Safety Gate (RAPEX) scraper for vehicle recalls
"""

import logging
import json
from typing import List, Dict, Any
from bs4 import BeautifulSoup

from utils import (
    setup_logging, create_session, safe_get, safe_post,
    retry_on_exception, clean_text, parse_date
)
from database import AutomotiveDatabase
from config import DATA_SOURCES, RAW_DATA_DIR


logger = setup_logging()


class EUSafetyGateScraper:
    """Scraper for EU Safety Gate (formerly RAPEX) vehicle recalls"""
    
    def __init__(self):
        self.session = create_session()
        self.base_url = DATA_SOURCES["eu_safety_gate"]["base_url"]
        self.api_url = DATA_SOURCES["eu_safety_gate"]["api_url"]
        self.domain = "eu_safety_gate"
    
    @retry_on_exception(max_attempts=3)
    def search_recalls(self, category: str = "Motor vehicles", 
                       start_date: str = None, end_date: str = None,
                       page: int = 0, page_size: int = 25) -> Dict[str, Any]:
        """
        Search for vehicle recalls using the Safety Gate API
        
        Args:
            category: Product category (default: "Motor vehicles")
            start_date: Start date for search (YYYY-MM-DD)
            end_date: End date for search (YYYY-MM-DD)
            page: Page number (0-indexed)
            page_size: Number of results per page
        
        Returns:
            Dictionary containing search results
        """
        # Build search payload
        payload = {
            "searchCriteria": {
                "productCategory": category,
            },
            "pagination": {
                "page": page,
                "size": page_size
            }
        }
        
        if start_date:
            payload["searchCriteria"]["notificationDateFrom"] = start_date
        if end_date:
            payload["searchCriteria"]["notificationDateTo"] = end_date
        
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        try:
            response = safe_post(
                self.api_url,
                self.session,
                self.domain,
                json=payload,
                headers=headers
            )
            
            return response.json()
        except Exception as e:
            logging.error(f"Error searching Safety Gate: {e}")
            return {"results": [], "totalElements": 0}
    
    def extract_recall_data(self, alert: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract and normalize recall data from API response
        
        Args:
            alert: Single alert object from API response
        
        Returns:
            Normalized recall data dictionary
        """
        return {
            "reference_number": alert.get("reference"),
            "notification_date": parse_date(alert.get("notificationDate")),
            "country_of_origin": alert.get("countryOfOrigin"),
            "product_category": alert.get("productCategory"),
            "product_name": clean_text(alert.get("productDescription", "")),
            "brand": clean_text(alert.get("brand", "")),
            "type": clean_text(alert.get("type", "")),
            "model": clean_text(alert.get("model", "")),
            "risk_type": alert.get("riskType"),
            "risk_description": clean_text(alert.get("riskDescription", "")),
            "measures_taken": clean_text(alert.get("measuresTaken", "")),
            "notifying_country": alert.get("notifyingCountry"),
            "source_url": f"{self.base_url}?reference={alert.get('reference')}"
        }
    
    def scrape_all_recalls(self, start_date: str = None, end_date: str = None,
                           max_pages: int = None) -> List[Dict[str, Any]]:
        """
        Scrape all vehicle recalls from Safety Gate
        
        Args:
            start_date: Start date for search (YYYY-MM-DD)
            end_date: End date for search (YYYY-MM-DD)
            max_pages: Maximum number of pages to scrape (None for all)
        
        Returns:
            List of recall dictionaries
        """
        all_recalls = []
        page = 0
        page_size = 25
        
        logging.info(f"Starting Safety Gate scrape from {start_date} to {end_date}")
        
        while True:
            logging.info(f"Fetching page {page + 1}")
            
            results = self.search_recalls(
                start_date=start_date,
                end_date=end_date,
                page=page,
                page_size=page_size
            )
            
            if not results.get("results"):
                logging.info("No more results found")
                break
            
            # Process each alert
            for alert in results["results"]:
                recall_data = self.extract_recall_data(alert)
                all_recalls.append(recall_data)
            
            logging.info(f"Processed {len(results['results'])} recalls from page {page + 1}")
            
            # Check if we should continue
            total_elements = results.get("totalElements", 0)
            if (page + 1) * page_size >= total_elements:
                logging.info("Reached end of results")
                break
            
            if max_pages and page + 1 >= max_pages:
                logging.info(f"Reached max_pages limit: {max_pages}")
                break
            
            page += 1
        
        logging.info(f"Scraped {len(all_recalls)} total recalls from Safety Gate")
        
        # Save raw data
        raw_file = RAW_DATA_DIR / f"safety_gate_recalls_{start_date}_{end_date}.json"
        with open(raw_file, 'w', encoding='utf-8') as f:
            json.dump(all_recalls, f, indent=2, ensure_ascii=False)
        logging.info(f"Saved raw data to {raw_file}")
        
        return all_recalls
    
    def scrape_and_save(self, start_date: str = None, end_date: str = None,
                        max_pages: int = None) -> int:
        """
        Scrape recalls and save to database
        
        Args:
            start_date: Start date for search (YYYY-MM-DD)
            end_date: End date for search (YYYY-MM-DD)
            max_pages: Maximum number of pages to scrape
        
        Returns:
            Number of recalls saved
        """
        recalls = self.scrape_all_recalls(start_date, end_date, max_pages)
        
        # Save to database
        saved_count = 0
        with AutomotiveDatabase() as db:
            for recall in recalls:
                if db.insert_recall(recall):
                    saved_count += 1
            
            db.log_scrape("eu_safety_gate", saved_count, "success")
        
        logging.info(f"Saved {saved_count} recalls to database")
        return saved_count


if __name__ == "__main__":
    # Example usage
    scraper = EUSafetyGateScraper()
    
    # Scrape last 6 months of data
    from datetime import datetime, timedelta
    end_date = datetime.now().strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=180)).strftime("%Y-%m-%d")
    
    count = scraper.scrape_and_save(start_date=start_date, end_date=end_date)
    print(f"Scraped and saved {count} vehicle recalls")

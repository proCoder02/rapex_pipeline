"""
Configuration settings for automotive data scraping pipeline
"""

import os
from pathlib import Path

# Base directories
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
LOGS_DIR = BASE_DIR / "logs"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"

# Create directories if they don't exist
for directory in [DATA_DIR, LOGS_DIR, RAW_DATA_DIR, PROCESSED_DATA_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# Scraping settings
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# Rate limiting settings (requests per minute)
RATE_LIMITS = {
    "eu_safety_gate": 10,  # 10 requests per minute
    "euro_ncap": 8,
    "default": 5
}

# Retry settings
MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds
BACKOFF_FACTOR = 2

# Data sources
DATA_SOURCES = {
    "eu_safety_gate": {
        "base_url": "https://ec.europa.eu/safety-gate-alerts/screen/search",
        "api_url": "https://ec.europa.eu/safety-gate-alerts/screen/webservice/search",
        "description": "EU Safety Gate (RAPEX) - Product recalls and alerts"
    },
    "euro_ncap": {
        "base_url": "https://www.euroncap.com",
        "results_url": "https://www.euroncap.com/en/results/",
        "description": "Euro NCAP - Vehicle safety ratings"
    }
}

# Database settings
DB_PATH = DATA_DIR / "automotive_data.db"

# Logging settings
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_FILE = LOGS_DIR / "scraping.log"

# Export settings
EXPORT_FORMATS = ["csv", "json", "excel"]

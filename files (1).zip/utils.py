"""
Utility functions for web scraping pipeline
"""

import time
import logging
import functools
from typing import Callable, Any
from collections import defaultdict
from datetime import datetime, timedelta
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from config import (
    LOG_LEVEL, LOG_FORMAT, LOG_FILE, 
    MAX_RETRIES, RETRY_DELAY, BACKOFF_FACTOR,
    USER_AGENT, RATE_LIMITS
)


class RateLimiter:
    """Rate limiter to control request frequency"""
    
    def __init__(self):
        self.requests = defaultdict(list)
    
    def wait_if_needed(self, domain: str, requests_per_minute: int = None):
        """
        Wait if necessary to comply with rate limiting
        
        Args:
            domain: Domain or identifier for rate limiting
            requests_per_minute: Maximum requests per minute
        """
        if requests_per_minute is None:
            requests_per_minute = RATE_LIMITS.get(domain, RATE_LIMITS["default"])
        
        now = datetime.now()
        minute_ago = now - timedelta(minutes=1)
        
        # Remove old requests
        self.requests[domain] = [
            req_time for req_time in self.requests[domain] 
            if req_time > minute_ago
        ]
        
        # Check if we need to wait
        if len(self.requests[domain]) >= requests_per_minute:
            oldest_request = min(self.requests[domain])
            sleep_time = 60 - (now - oldest_request).total_seconds()
            if sleep_time > 0:
                logging.info(f"Rate limit reached for {domain}. Sleeping for {sleep_time:.2f} seconds")
                time.sleep(sleep_time)
        
        # Record this request
        self.requests[domain].append(now)


# Global rate limiter instance
rate_limiter = RateLimiter()


def setup_logging():
    """Configure logging for the application"""
    logging.basicConfig(
        level=getattr(logging, LOG_LEVEL),
        format=LOG_FORMAT,
        handlers=[
            logging.FileHandler(LOG_FILE),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)


def create_session() -> requests.Session:
    """
    Create a requests session with retry logic and proper headers
    
    Returns:
        Configured requests Session object
    """
    session = requests.Session()
    
    # Configure retry strategy
    retry_strategy = Retry(
        total=MAX_RETRIES,
        backoff_factor=BACKOFF_FACTOR,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"]
    )
    
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    # Set default headers
    session.headers.update({
        'User-Agent': USER_AGENT,
        'Accept': 'application/json, text/html, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
    })
    
    return session


def retry_on_exception(max_attempts: int = MAX_RETRIES, delay: int = RETRY_DELAY):
    """
    Decorator to retry a function on exception
    
    Args:
        max_attempts: Maximum number of retry attempts
        delay: Initial delay between retries (seconds)
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            attempts = 0
            current_delay = delay
            
            while attempts < max_attempts:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    attempts += 1
                    if attempts >= max_attempts:
                        logging.error(f"Function {func.__name__} failed after {max_attempts} attempts: {e}")
                        raise
                    
                    logging.warning(
                        f"Attempt {attempts} failed for {func.__name__}: {e}. "
                        f"Retrying in {current_delay} seconds..."
                    )
                    time.sleep(current_delay)
                    current_delay *= BACKOFF_FACTOR
            
            return None
        
        return wrapper
    return decorator


def safe_get(url: str, session: requests.Session, domain: str, **kwargs) -> requests.Response:
    """
    Safely make a GET request with rate limiting and error handling
    
    Args:
        url: URL to fetch
        session: Requests session object
        domain: Domain identifier for rate limiting
        **kwargs: Additional arguments to pass to requests.get()
    
    Returns:
        Response object
    """
    rate_limiter.wait_if_needed(domain)
    
    try:
        response = session.get(url, timeout=30, **kwargs)
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching {url}: {e}")
        raise


def safe_post(url: str, session: requests.Session, domain: str, **kwargs) -> requests.Response:
    """
    Safely make a POST request with rate limiting and error handling
    
    Args:
        url: URL to post to
        session: Requests session object
        domain: Domain identifier for rate limiting
        **kwargs: Additional arguments to pass to requests.post()
    
    Returns:
        Response object
    """
    rate_limiter.wait_if_needed(domain)
    
    try:
        response = session.post(url, timeout=30, **kwargs)
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        logging.error(f"Error posting to {url}: {e}")
        raise


def parse_date(date_string: str) -> str:
    """
    Parse various date formats to ISO format
    
    Args:
        date_string: Date string in various formats
    
    Returns:
        Date in ISO format (YYYY-MM-DD) or original string if parsing fails
    """
    if not date_string:
        return None
    
    formats = [
        "%Y-%m-%d",
        "%d/%m/%Y",
        "%m/%d/%Y",
        "%d-%m-%Y",
        "%Y/%m/%d",
        "%B %d, %Y",
        "%d %B %Y"
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_string.strip(), fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    
    logging.warning(f"Could not parse date: {date_string}")
    return date_string


def clean_text(text: str) -> str:
    """
    Clean and normalize text data
    
    Args:
        text: Raw text string
    
    Returns:
        Cleaned text string
    """
    if not text:
        return ""
    
    # Remove extra whitespace
    text = " ".join(text.split())
    # Remove special characters that might cause issues
    text = text.replace('\x00', '')
    
    return text.strip()

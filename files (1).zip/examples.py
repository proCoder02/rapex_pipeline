"""
Example usage scripts for the automotive data pipeline
"""

from datetime import datetime, timedelta
from pipeline import AutomotiveDataPipeline
from database import AutomotiveDatabase
import pandas as pd


def example_1_quick_start():
    """Example 1: Quick start - scrape last 30 days"""
    print("=" * 80)
    print("EXAMPLE 1: Quick Start - Scrape Last 30 Days")
    print("=" * 80)
    
    pipeline = AutomotiveDataPipeline()
    
    # Scrape recent recalls
    recalls_count = pipeline.run_safety_gate_scrape(days_back=30)
    print(f"\nScraped {recalls_count} recalls from the last 30 days")
    
    pipeline.close()


def example_2_specific_year():
    """Example 2: Get safety ratings for specific year"""
    print("=" * 80)
    print("EXAMPLE 2: Get Safety Ratings for 2023")
    print("=" * 80)
    
    pipeline = AutomotiveDataPipeline()
    
    # Scrape only 2023 ratings
    ratings_count = pipeline.run_euro_ncap_scrape(start_year=2023, end_year=2023)
    print(f"\nScraped {ratings_count} safety ratings from 2023")
    
    pipeline.close()


def example_3_data_analysis():
    """Example 3: Analyze scraped data"""
    print("=" * 80)
    print("EXAMPLE 3: Analyze Scraped Data")
    print("=" * 80)
    
    with AutomotiveDatabase() as db:
        # Get recalls
        recalls_df = db.get_recalls()
        
        if len(recalls_df) > 0:
            print(f"\nTotal Recalls: {len(recalls_df)}")
            print("\nTop 5 Countries by Recall Count:")
            print(recalls_df['notifying_country'].value_counts().head())
            
            print("\nTop 5 Brands with Recalls:")
            print(recalls_df['brand'].value_counts().head())
            
            print("\nRisk Types Distribution:")
            print(recalls_df['risk_type'].value_counts())
        else:
            print("\nNo recall data available. Run the scraper first!")
        
        # Get safety ratings
        ratings_df = db.get_safety_ratings()
        
        if len(ratings_df) > 0:
            print(f"\n\nTotal Safety Ratings: {len(ratings_df)}")
            print(f"\nAverage Overall Rating: {ratings_df['overall_rating'].mean():.2f} stars")
            
            print("\nTop 10 Safest Vehicles (by overall rating):")
            top_safe = ratings_df.nlargest(10, 'overall_rating')[
                ['make', 'model', 'year', 'overall_rating']
            ]
            print(top_safe.to_string(index=False))
            
            print("\nTop 10 Makes by Number of Tests:")
            print(ratings_df['make'].value_counts().head(10))
        else:
            print("\nNo safety rating data available. Run the scraper first!")


def example_4_export_filtered_data():
    """Example 4: Export filtered data"""
    print("=" * 80)
    print("EXAMPLE 4: Export Filtered Data")
    print("=" * 80)
    
    with AutomotiveDatabase() as db:
        # Get all recalls
        recalls_df = db.get_recalls()
        
        if len(recalls_df) > 0:
            # Filter recalls by specific country
            german_recalls = recalls_df[recalls_df['notifying_country'] == 'Germany']
            
            if len(german_recalls) > 0:
                output_file = 'data/processed/german_recalls.csv'
                german_recalls.to_csv(output_file, index=False)
                print(f"\nExported {len(german_recalls)} German recalls to {output_file}")
            else:
                print("\nNo German recalls found")
        
        # Get safety ratings and filter
        ratings_df = db.get_safety_ratings()
        
        if len(ratings_df) > 0:
            # Filter 5-star vehicles
            five_star = ratings_df[ratings_df['overall_rating'] == 5.0]
            
            if len(five_star) > 0:
                output_file = 'data/processed/five_star_vehicles.csv'
                five_star.to_csv(output_file, index=False)
                print(f"Exported {len(five_star)} 5-star vehicles to {output_file}")
            else:
                print("\nNo 5-star vehicles found")


def example_5_incremental_updates():
    """Example 5: Incremental updates - scrape only new data"""
    print("=" * 80)
    print("EXAMPLE 5: Incremental Updates")
    print("=" * 80)
    
    pipeline = AutomotiveDataPipeline()
    
    # Get most recent recall date from database
    with AutomotiveDatabase() as db:
        recalls_df = db.get_recalls(limit=1)
        
        if len(recalls_df) > 0:
            last_date = recalls_df['notification_date'].iloc[0]
            print(f"\nLast recall in database: {last_date}")
            print("Scraping only newer data...")
            
            # Calculate days since last scrape
            try:
                last_datetime = datetime.strptime(last_date, "%Y-%m-%d")
                days_since = (datetime.now() - last_datetime).days
                
                # Scrape with small buffer
                recalls_count = pipeline.run_safety_gate_scrape(days_back=days_since + 7)
                print(f"Scraped {recalls_count} new recalls")
            except:
                print("Could not parse date, running default scrape")
                recalls_count = pipeline.run_safety_gate_scrape(days_back=30)
        else:
            print("\nNo existing data. Running initial scrape...")
            recalls_count = pipeline.run_safety_gate_scrape(days_back=180)
    
    pipeline.close()


def example_6_combined_analysis():
    """Example 6: Combined analysis - recalls vs safety ratings"""
    print("=" * 80)
    print("EXAMPLE 6: Combined Analysis - Recalls vs Safety Ratings")
    print("=" * 80)
    
    with AutomotiveDatabase() as db:
        recalls_df = db.get_recalls()
        ratings_df = db.get_safety_ratings()
        
        if len(recalls_df) > 0 and len(ratings_df) > 0:
            # Count recalls by brand
            recall_counts = recalls_df['brand'].value_counts().reset_index()
            recall_counts.columns = ['brand', 'recall_count']
            
            # Average safety rating by make
            avg_ratings = ratings_df.groupby('make')['overall_rating'].agg([
                'mean', 'count'
            ]).reset_index()
            avg_ratings.columns = ['brand', 'avg_rating', 'rating_count']
            
            # Merge data (normalize brand names for better matching)
            recall_counts['brand'] = recall_counts['brand'].str.upper().str.strip()
            avg_ratings['brand'] = avg_ratings['brand'].str.upper().str.strip()
            
            combined = pd.merge(recall_counts, avg_ratings, on='brand', how='outer')
            combined = combined.fillna(0)
            combined = combined.sort_values('recall_count', ascending=False).head(15)
            
            print("\nTop 15 Brands: Recalls vs Safety Ratings")
            print(combined.to_string(index=False))
            
            # Export combined analysis
            output_file = 'data/processed/combined_analysis.csv'
            combined.to_csv(output_file, index=False)
            print(f"\nExported combined analysis to {output_file}")
        else:
            print("\nInsufficient data for combined analysis")


def example_7_test_mode():
    """Example 7: Test mode - limited scraping for testing"""
    print("=" * 80)
    print("EXAMPLE 7: Test Mode - Limited Scraping")
    print("=" * 80)
    
    pipeline = AutomotiveDataPipeline()
    
    # Scrape just a few pages for testing
    print("\nTesting Safety Gate scraper (max 2 pages)...")
    recalls_count = pipeline.run_safety_gate_scrape(days_back=30, max_pages=2)
    print(f"Test scraped {recalls_count} recalls")
    
    print("\nTesting Euro NCAP scraper (current year only)...")
    current_year = datetime.now().year
    ratings_count = pipeline.run_euro_ncap_scrape(
        start_year=current_year,
        end_year=current_year
    )
    print(f"Test scraped {ratings_count} safety ratings")
    
    pipeline.close()


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("AUTOMOTIVE DATA PIPELINE - EXAMPLE USAGE SCRIPTS")
    print("=" * 80 + "\n")
    
    print("Available examples:")
    print("1. Quick start - scrape last 30 days")
    print("2. Get safety ratings for specific year")
    print("3. Analyze scraped data")
    print("4. Export filtered data")
    print("5. Incremental updates")
    print("6. Combined analysis")
    print("7. Test mode - limited scraping")
    
    choice = input("\nEnter example number (1-7) or 'all' to run all: ").strip()
    
    examples = {
        '1': example_1_quick_start,
        '2': example_2_specific_year,
        '3': example_3_data_analysis,
        '4': example_4_export_filtered_data,
        '5': example_5_incremental_updates,
        '6': example_6_combined_analysis,
        '7': example_7_test_mode,
    }
    
    if choice.lower() == 'all':
        for func in examples.values():
            func()
            print("\n")
    elif choice in examples:
        examples[choice]()
    else:
        print("Invalid choice!")

# Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Test the Pipeline
```bash
# Test mode - scrapes just a few pages
python examples.py
# Choose option 7 when prompted
```

### Step 3: Run a Quick Scrape
```bash
# Scrape last 30 days of recalls
python pipeline.py --safety-gate --days 30
```

### Step 4: View Your Data
```bash
# See what you collected
python pipeline.py --stats
```

### Step 5: Export Data
The data is automatically exported to:
- **Database**: `data/automotive_data.db`
- **CSV files**: `data/processed/*.csv`
- **Excel**: `data/processed/automotive_data_*.xlsx`

## 📊 Common Use Cases

### Get Recent Vehicle Recalls
```bash
python pipeline.py --safety-gate --days 90
```

### Get Safety Ratings for Recent Years
```bash
python pipeline.py --euro-ncap --start-year 2020
```

### Run Everything (Full Pipeline)
```bash
python pipeline.py --full
```

### Analyze Data with Python
```python
from database import AutomotiveDatabase

with AutomotiveDatabase() as db:
    # Get all recalls
    recalls = db.get_recalls()
    print(recalls.head())
    
    # Get safety ratings
    ratings = db.get_safety_ratings()
    print(ratings.head())
```

## 🎯 Next Steps

1. **Read the full README**: `README.md`
2. **Check legal compliance**: `LEGAL_COMPLIANCE.md`
3. **Explore examples**: `examples.py`
4. **Customize config**: `config.py`

## ⚠️ Important Notes

1. **Legal**: Always check Terms of Service before scraping
2. **Rate Limiting**: Built-in delays prevent server overload
3. **Ethics**: Use responsibly and respect website resources

## 🆘 Troubleshooting

**Problem**: Module not found
```bash
# Solution: Install dependencies
pip install -r requirements.txt
```

**Problem**: Rate limiting errors
```python
# Solution: Reduce rate in config.py
RATE_LIMITS = {"default": 3}  # Slower scraping
```

**Problem**: No data scraped
```bash
# Solution: Check logs
tail -f logs/scraping.log
```

## 📚 Resources

- **Full Documentation**: `README.md`
- **Legal Guide**: `LEGAL_COMPLIANCE.md`
- **Example Scripts**: `examples.py`
- **Configuration**: `config.py`

Happy scraping! 🎉
